from django.contrib import admin
from .models import Billing, Order

admin.site.register(Billing)
admin.site.register(Order)
