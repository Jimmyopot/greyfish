from django.apps import AppConfig


class BodyMassIndexConfig(AppConfig):
    name = 'body_mass_index'
